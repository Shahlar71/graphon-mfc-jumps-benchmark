"""Closed-form benchmark of Section 6.2.

Two-label linear-quadratic graphon model (6.12) with additive jumps.  By
Proposition 6.1 the Riccati system is that of the jump-free model and the jumps
enter the value only through the compensator (6.11).  The script solves

  * the fluctuation Riccati equation, one scalar equation per label,
        K' = -2 A K + B^2 K^2 / R - Q,          K_T = P,
  * the mean Riccati equation, a 2x2 matrix equation,
        Pi' + Pi (A+G) + (A+G*) Pi - Pi B R^{-1} B Pi + Q = 0,   Pi_T = P,

and reproduces K_0, Pi_0, Y_0 = Pi_0 E[xi] and the decomposition (6.13) of the
optimal value V_0 into its fluctuation, mean and noise-compensation parts.

Normalisation: the cost carries the factor 1/2 of (6.2), so that v = K x^2 / 2
and Y = K x on the fluctuation part.
"""
import numpy as np
from scipy.integrate import solve_ivp

# ---------------------------------------------------------------- data (6.12)
A = np.array([-0.50, -0.80]); B = np.array([1.00, 0.70])
Q = np.array([1.00, 0.60]);  R = np.array([0.50, 0.80])
P = np.array([1.20, 0.40]);  sigma = np.array([0.30, 0.20])
eta = np.array([0.40, -0.25]); lam = np.array([2.00, 3.00])
GA = np.array([[0.0, 0.60], [0.90, 0.0]])
w = np.array([0.5, 0.5])                       # masses of the two blocks
E_xi = np.array([0.50, 0.20]); Var_xi = np.array([0.10, 0.05]); T = 1.0

TOL = dict(rtol=1e-12, atol=1e-14)

# ---------------------------------------------------------------- Riccati
# time is reversed, s = T - t, so that both equations run forward in s
fluct = solve_ivp(lambda s, K: -(-2*A*K + B**2*K**2/R - Q), [0, T], P,
                  dense_output=True, **TOL)
K0 = fluct.y[:, -1]
int_K = np.array([solve_ivp(lambda s, y, i=i: [fluct.sol(s)[i]], [0, T], [0.0],
                            **TOL).y[0, -1] for i in range(2)])

G = w[None, :] * GA                            # G_uv = w_v G_A(u, v)
S = np.diag(B) @ np.linalg.inv(np.diag(R)) @ np.diag(B)
def mean_rhs(s, y):
    Pi = y.reshape(2, 2)
    return (Pi @ (np.diag(A) + G) + (np.diag(A) + G.T) @ Pi
            - Pi @ S @ Pi + np.diag(Q)).reshape(-1)
Pi0 = solve_ivp(mean_rhs, [0, T], np.diag(P).reshape(-1), **TOL).y[:, -1].reshape(2, 2)

# ---------------------------------------------------------------- value (6.13)
Y0 = Pi0 @ E_xi
v_fluct = 0.5 * np.sum(w * K0 * Var_xi)
v_mean = 0.5 * np.sum(w * E_xi * (Pi0 @ E_xi))
v_noise = 0.5 * np.sum(w * (sigma**2 + lam * eta**2) * int_K)
v_noise_nojump = 0.5 * np.sum(w * sigma**2 * int_K)
V0 = v_fluct + v_mean + v_noise
V0_nojump = v_fluct + v_mean + v_noise_nojump

np.set_printoptions(precision=6, suppress=True)
print("K_0            ", K0)
print("Pi_0           ", Pi0.round(6).tolist())
print("Y_0 = Pi_0 E xi", Y0)
print()
print(f"V_0 = {v_fluct:.6f} (fluctuation) + {v_mean:.6f} (mean) "
      f"+ {v_noise:.6f} (noise) = {V0:.6f}")
print(f"V_0 without jumps          = {V0_nojump:.6f}")
print(f"share of V_0 due to jumps  = {100 * (V0 - V0_nojump) / V0:.1f}%")
