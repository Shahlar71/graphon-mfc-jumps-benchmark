"""Independent check of Table 1 of Section 6.2: Euler-Maruyama convergence of the
closed-loop cost against the exact value V0 of (6.13).

Two-label graphon LQ model (6.12), closed loop under the exact feedback (6.10),
jump-adapted Euler-Maruyama with N steps and M Monte-Carlo paths.
"""
import numpy as np
from scipy.integrate import solve_ivp

A = np.array([-0.50, -0.80]); B = np.array([1.00, 0.70])
Q = np.array([1.00, 0.60]);  R = np.array([0.50, 0.80])
P = np.array([1.20, 0.40]);  sg = np.array([0.30, 0.20])
eta = np.array([0.40, -0.25]); lam = np.array([2.00, 3.00])
GA = np.array([[0.0, 0.60], [0.90, 0.0]]); w = np.array([0.5, 0.5])
Exi = np.array([0.50, 0.20]); Vxi = np.array([0.10, 0.05]); T = 1.0

# ---- Riccati: fluctuation (scalar per label) and mean (2x2) -------------------
f1 = lambda t, K: -(-2*A*K + B**2*K**2/R - Q)                 # s = T-t
s1 = solve_ivp(f1, [0, T], P, rtol=1e-12, atol=1e-14, dense_output=True)
Am, Bm, Rm, Qm, Pm = np.diag(A), np.diag(B), np.diag(R), np.diag(Q), np.diag(P)
G = w[None, :]*GA; S = Bm@np.linalg.inv(Rm)@Bm
f2 = lambda t, y: (y.reshape(2, 2)@(Am+G) + (Am+G.T)@y.reshape(2, 2)
                   - y.reshape(2, 2)@S@y.reshape(2, 2) + Qm).reshape(-1)
s2 = solve_ivp(f2, [0, T], Pm.reshape(-1), rtol=1e-12, atol=1e-14, dense_output=True)
K = lambda t: s1.sol(T-t); Pi = lambda t: s2.sol(T-t).reshape(2, 2)

intK = np.array([solve_ivp(lambda t, y, i=i: [s1.sol(t)[i]], [0, T], [0.0],
                           rtol=1e-12, atol=1e-14).y[0, -1] for i in range(2)])
V0 = 0.5*(np.sum(w*K(0)*Vxi) + np.sum(w*Exi*(Pi(0)@Exi))
          + np.sum(w*(sg**2 + lam*eta**2)*intK))

# ---- closed-loop Euler-Maruyama ---------------------------------------------
def run(N, M, seed=0):
    rng = np.random.default_rng(seed)
    dt = T/N
    X = Exi + np.sqrt(Vxi)*rng.standard_normal((M, 2))
    xbar = Exi.copy(); cost = np.zeros(M)
    for i in range(N):
        t = i*dt; Kt, Pit = K(t), Pi(t)
        al = -(B/R)*(Kt*(X - xbar) + (Pit@xbar))
        cost += 0.5*dt*np.sum(w*(Q*X**2 + R*al**2), axis=1)
        drift = A*X + xbar@(w[None, :]*GA).T + B*al
        dW = np.sqrt(dt)*rng.standard_normal((M, 2))
        dN = rng.poisson(lam*dt, size=(M, 2))
        X = X + drift*dt + sg*dW + eta*(dN - lam*dt)
        xbar = xbar + (A*xbar + (w[None, :]*GA)@xbar - (B**2/R)*(Pit@xbar))*dt
    cost += 0.5*np.sum(w*P*X**2, axis=1)
    return cost.mean(), cost.std(ddof=1)/np.sqrt(M)

print(f"exact V0 = {V0:.6f}   (paper: 0.151998)\n")
print(f"{'N':>4} {'MC estimate':>13} {'std err':>11} {'bias':>11} {'ratio':>7}")
prev = None
for N in (10, 20, 40, 80):
    m, se = run(N, 200_000)
    bias = m - V0
    print(f"{N:>4} {m:>13.6f} {se:>11.2e} {bias:>11.2e}"
          + (f" {prev/bias:>7.2f}" if prev else " " * 8))
    prev = bias
