# Closed-form benchmark and Euler validation

Code accompanying Section 6.2 of

> S. Meherrem and T. Guluzade,
> *Stochastic optimal control of graphon mean-field systems with jumps.*

Section 6.2 constructs the only exactly solvable instance of the paper: a
two-label linear-quadratic graphon model with additive jumps, for which the
optimal value, the adjoint and the optimal feedback are known in closed form.
It is the reference against which the Euler-Maruyama scheme of Table 1 and every
result of Section 7 are measured. This repository reproduces those reference
values and the convergence study.

## Requirements

    python >= 3.10
    pip install -r requirements.txt

No GPU is needed; both scripts run in a few minutes on a single CPU core.

## Contents

| file              | reproduces                                                            |
|-------------------|------------------------------------------------------------------------|
| `verify_lq.py`    | the Riccati solution of Proposition 6.1 and the decomposition (6.13) of the optimal value |
| `verify_euler.py` | Table 1: the closed-loop Euler-Maruyama estimates against the exact value |

## Expected output

`python3 verify_lq.py`

    K_0             [0.524144 0.341531]
    Pi_0            [[0.55106, 0.119623], [0.119623, 0.35859]]
    Y_0 = Pi_0 E xi [0.299455 0.131529]

    V_0 = 0.017373 (fluctuation) + 0.044008 (mean) + 0.090616 (noise) = 0.151998
    V_0 without jumps          = 0.080374
    share of V_0 due to jumps  = 47.1%

`python3 verify_euler.py`

    exact V0 = 0.151998

       N   MC estimate     std err        bias   ratio
      10      0.163243    2.97e-04    1.12e-02
      20      0.157293    2.92e-04    5.30e-03    2.12
      40      0.154604    2.89e-04    2.61e-03    2.03
      80      0.153298    2.90e-04    1.30e-03    2.01

The Monte-Carlo estimates agree with those of Table 1 to within one or two
standard errors. The bias against the exact value halves as the number of steps
doubles, which is the weak order one of the scheme.

## Notes

The cost functional carries the factor 1/2 of (6.2); with this normalisation the
value function is `K x^2 / 2` on the fluctuation part and the first adjoint is
`Y = K x`, as in the ansatz (6.5).

All random numbers are drawn from a seeded generator, so the Euler study
repeats exactly on the same platform.

## Licence

MIT, see `LICENSE`.
